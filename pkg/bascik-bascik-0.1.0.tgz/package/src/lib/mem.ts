import zlib from "node:zlib";
import { getHttpPath } from "./paths.js";
import { getRelativePath } from "./file-system.js";
import type { StoredPage } from "./types.js";

interface StorePageArgs {
  relativePagePath: string;
  absolutePagePath: string;
  pageContent: string;
  usedComponentsNames?: string[];
}

class MemoryStore {
  #files: Map<string, StoredPage>;
  #components: Map<string, Set<string>>;

  constructor() {
    this.#files = new Map();
    this.#components = new Map();
  }

  storePage({
    relativePagePath,
    absolutePagePath,
    pageContent,
    usedComponentsNames = [],
  }: StorePageArgs): void {
    const httpPath = getHttpPath(relativePagePath);

    //this.#files.set(httpPath, pageContent)
    const buffer = Buffer.from(pageContent, "utf8");

    const br = zlib.brotliCompressSync(buffer);

    const usedComponentsSet = new Set(usedComponentsNames);

    const originalUsedComponentSet = new Set(
      this.#files.get(httpPath)?.usedComponentsSet,
    );

    // More efficient to send Buffers to http2 stream.end()
    this.#files.set(httpPath, {
      relativePagePath,
      absolutePagePath,
      content: buffer,
      compressedContent: br,
      usedComponentsSet,
    });

    // Invert map for reverse lookup to efficiently know what files to update
    // Create entries in the map for each component name,
    // and add this file to a Set associated with the component.
    usedComponentsSet.forEach((componentName: string) => {
      if (!this.#components.has(componentName)) {
        this.#components.set(componentName, new Set());
      }
      this.#components.get(componentName)!.add(absolutePagePath);
    });

    // If a page no longer has component, remove that page from the component's set.
    //  ex: pageA has tag1 and tag2. then tag2 is removed from pageA.
    // tag2 should remove pageA from it's set.
    originalUsedComponentSet
      .difference(usedComponentsSet)
      .forEach((unusedComponent: string) => {
        this.#components.get(unusedComponent)?.delete(absolutePagePath);
      });

    //console.log('stored page in memory:', httpPath)
  }

  getPage(httpPath: string): StoredPage | undefined {
    return this.#files.get(httpPath) || this.#files.get("/404");
  }

  removePage(absolutePagePath: string): void {
    const relativePagePath = getRelativePath(absolutePagePath, "pages");
    const httpPath = getHttpPath(relativePagePath);

    // Remove page from components sets
    const page = this.#files.get(httpPath);
    if (!page) return;
    page.usedComponentsSet.forEach((componentName: string) => {
      this.#components.get(componentName)?.delete(absolutePagePath);
    });

    // Remove page from memory
    this.#files.delete(httpPath);
  }

  pagesThisComponentIsUsedOn(componentName: string): string[] {
    const pagesSet = this.#components.get(componentName);
    if (pagesSet) return [...pagesSet];
    return [];
  }
}

export const mem = new MemoryStore();
