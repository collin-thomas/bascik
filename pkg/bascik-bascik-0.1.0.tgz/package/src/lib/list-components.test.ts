/**
 * Tests for listComponents – specifically the ordering guarantee that
 * executeBuildScripts runs on the raw HTML *before* minifyHtml.
 *
 * Why the order matters: minifyHtml extracts all <script> tags and appends
 * them after the HTML. If minifyHtml ran first, a <script data-bascik-build>
 * inside a container (e.g. <aside>) would be hoisted out of that container
 * before executeBuildScripts could replace it, causing the generated content
 * to appear outside the container in the final output.
 */
import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── Mocks ───────────────────────────────────────────────────────────────────

vi.mock("./config.js", () => ({
  BascikConfig: {
    directory: { components: "src/components" },
    verboseLogging: false,
    obfuscateAttributeNames: false,
    deduplicateCss: true,
    minifyStyles: false,
    skipTranspilingElementContents: [],
  },
}));

vi.mock("./file-system.js", () => ({
  deepReadDirFlat: vi.fn(),
}));

vi.mock("./styles.js", () => ({
  getComponentCss: vi.fn(async () => ""),
}));

vi.mock("./build-scripts.js", () => ({
  executeBuildScripts: vi.fn(async (html: string) => html),
}));

vi.mock("node:fs/promises", () => ({
  readFile: vi.fn(),
}));

import { listComponents, minifyHtml } from "./components.js";
import { deepReadDirFlat } from "./file-system.js";
import { executeBuildScripts } from "./build-scripts.js";
import { readFile } from "node:fs/promises";

const mockDeepReadDirFlat = deepReadDirFlat as ReturnType<typeof vi.fn>;
const mockExecuteBuildScripts = executeBuildScripts as ReturnType<typeof vi.fn>;
const mockReadFile = readFile as ReturnType<typeof vi.fn>;

beforeEach(() => {
  vi.clearAllMocks();
  // Default: executeBuildScripts is a pass-through (no build scripts in HTML)
  mockExecuteBuildScripts.mockImplementation(async (html: string) => html);
  // Default: no CSS file exists alongside the component
  mockDeepReadDirFlat.mockResolvedValue([]);
});

// ─────────────────────────────────────────────────────────────────────────────
// minifyHtml script-hoisting behavior (documents the ordering constraint)
// ─────────────────────────────────────────────────────────────────────────────

describe("minifyHtml – script hoisting (documents build-script ordering requirement)", () => {
  it("moves a <script> tag out of its container to end of the string", () => {
    // This is intentional minifyHtml behaviour — it consolidates scripts at
    // the bottom. But it means executeBuildScripts MUST run before minifyHtml;
    // otherwise the script would be hoisted before it can be replaced.
    const html = "<aside><script data-bascik-build>gen()</script></aside>";
    const minified = minifyHtml(html);

    // Script is moved outside the aside
    expect(minified).toContain("<aside></aside>");
    // Script appears after the closing aside tag
    const asideEnd = minified.indexOf("</aside>");
    const scriptStart = minified.indexOf("<script");
    expect(scriptStart).toBeGreaterThan(asideEnd);
  });

  it("would cause generated content to appear outside its container if order were reversed", () => {
    // Simulate the wrong order: minifyHtml first, then replace script with content.
    // The generated <li> items would end up after </ul>, not inside it.
    const raw = "<ul><script data-bascik-build>makeList()</script></ul>";
    const minified = minifyHtml(raw);
    // If we now naively replace the script with generated content:
    const wrongOrder = minified.replace(
      /<script[^>]*>[\s\S]*?<\/script>/,
      "<li>item</li>",
    );
    // Content is outside the <ul> — this is the bug the fix prevents
    expect(wrongOrder).toMatch(/<\/ul>.*<li>/s);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// listComponents – executeBuildScripts runs before minifyHtml
// ─────────────────────────────────────────────────────────────────────────────

describe("listComponents – build script execution order", () => {
  it("calls executeBuildScripts with the raw file content for each component", async () => {
    const rawHtml =
      '<aside class="sidebar"><script data-bascik-build>gen()</script></aside>';
    mockDeepReadDirFlat.mockResolvedValue(["src/components/my-sidebar.html"]);
    mockReadFile.mockResolvedValue(Buffer.from(rawHtml));

    await listComponents();

    expect(mockExecuteBuildScripts).toHaveBeenCalledWith(
      rawHtml,
      "src/components/my-sidebar.html",
    );
  });

  it("places build script output inside the container, not after it", async () => {
    const rawHtml =
      "<aside><script data-bascik-build>gen()</script></aside>";
    // Simulate executeBuildScripts replacing the script with real content
    const resolvedHtml =
      "<aside><p>Section</p><ul><li>Link</li></ul></aside>";

    mockDeepReadDirFlat.mockResolvedValue(["src/components/my-sidebar.html"]);
    mockReadFile.mockResolvedValue(Buffer.from(rawHtml));
    mockExecuteBuildScripts.mockResolvedValue(resolvedHtml);

    const result = await listComponents();

    expect(result["my-sidebar"]).toBeDefined();
    const fileContent = result["my-sidebar"].fileContent;
    // Generated content is inside the aside
    expect(fileContent).toContain("<aside");
    expect(fileContent).toContain("Section");
    const asideClose = fileContent.indexOf("</aside>");
    const sectionIndex = fileContent.indexOf("Section");
    expect(sectionIndex).toBeLessThan(asideClose);
  });

  it("still minifies the resolved HTML after build scripts run", async () => {
    // executeBuildScripts returns HTML with whitespace; minifyHtml collapses it
    const rawHtml = "<nav><script data-bascik-build>gen()</script></nav>";
    const resolvedHtml =
      "<nav>\n  <ul>\n    <li>Home</li>\n  </ul>\n</nav>";

    mockDeepReadDirFlat.mockResolvedValue(["src/components/my-nav.html"]);
    mockReadFile.mockResolvedValue(Buffer.from(rawHtml));
    mockExecuteBuildScripts.mockResolvedValue(resolvedHtml);

    const result = await listComponents();

    // minifyHtml removes newlines and collapses whitespace
    expect(result["my-nav"].fileContent).not.toContain("\n");
    expect(result["my-nav"].fileContent).toContain("<li>Home</li>");
  });

  it("includes the component in the result when there are no build scripts", async () => {
    const rawHtml = "<nav><a href='/'>Home</a></nav>";

    mockDeepReadDirFlat.mockResolvedValue(["src/components/site-nav.html"]);
    mockReadFile.mockResolvedValue(Buffer.from(rawHtml));

    const result = await listComponents();

    expect(result["site-nav"]).toBeDefined();
    expect(result["site-nav"].fileContent).toContain("Home");
  });

  it("processes multiple components independently", async () => {
    mockDeepReadDirFlat.mockResolvedValue([
      "src/components/my-header.html",
      "src/components/my-footer.html",
    ]);
    mockReadFile
      .mockResolvedValueOnce(Buffer.from("<header><script data-bascik-build>h()</script></header>"))
      .mockResolvedValueOnce(Buffer.from("<footer><script data-bascik-build>f()</script></footer>"));
    mockExecuteBuildScripts
      .mockResolvedValueOnce("<header><h1>Title</h1></header>")
      .mockResolvedValueOnce("<footer><p>Copyright</p></footer>");

    const result = await listComponents();

    expect(result["my-header"].fileContent).toContain("Title");
    expect(result["my-footer"].fileContent).toContain("Copyright");
    // Each component's content in its own container
    expect(result["my-header"].fileContent).toContain("<header");
    expect(result["my-footer"].fileContent).toContain("<footer");
  });
});
